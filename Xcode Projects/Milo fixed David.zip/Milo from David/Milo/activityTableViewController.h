//
//  activityTableViewController.h
//  Milo
//
//  Created by Programming Account on 1/5/15.
//  Copyright (c) 2015 milo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface activityTableViewController : UITableViewController <UITableViewDelegate,UITableViewDataSource>

@end
