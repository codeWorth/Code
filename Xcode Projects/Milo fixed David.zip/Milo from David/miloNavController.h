//
//  miloNavController.h
//  Milo
//
//  Created by Andrew Cummings on 2/21/15.
//  Copyright (c) 2015 milo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface miloNavController : UINavigationController

@end
